#include <iostream>
#include <cmath>

using namespace std;

void timesShown(char arr[], int n)
{
    for (int i = 0; i < n; i++)
    {

    }
}

int main()
{
    int n;
    

    return 0;
}